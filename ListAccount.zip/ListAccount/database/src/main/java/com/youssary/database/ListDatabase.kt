package com.youssary.database

import androidx.room.Database

@Database(entities = [Movie::class], version = 1)
abstract class ListDatabase : RoomDatabase() {

    abstract fun movieDao(): ListDao
}